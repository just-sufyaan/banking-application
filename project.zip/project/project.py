import json
import os
from datetime import datetime

def load_accounts(filename="data/accounts.json"):
    """Load account data from a JSON file."""
    if not os.path.exists(filename):
        return {}  # Return an empty dictionary if the file doesn't exist
    try:
        with open(filename, "r") as file:
            return json.load(file)  # Load and return JSON data from the file
    except json.JSONDecodeError:
        return {}  # Return an empty dictionary if there's a JSON decoding error

def save_accounts(accounts, filename="data/accounts.json"):
    """Save account data to a JSON file."""
    with open(filename, "w") as file:
        json.dump(accounts, file, indent=4)  # Save accounts dictionary as JSON with indentation

def display_initial_menu():
    """Display the initial menu."""
    print("\n**********************************************")
    print("      Welcome to my Banking Application!      ")
    print("**********************************************")
    print("1. Create Account")
    print("2. Login")
    print("3. Exit")
    print("**********************************************")

def display_account_menu():
    """Display the account operations menu."""
    print("\n**********************************************")
    print("                Account Menu                  ")
    print("**********************************************")
    print("1. View Balance")
    print("2. Deposit")
    print("3. Withdraw")
    print("4. Transfer")
    print("5. View Transaction History")
    print("6. Update Information")
    print("7. Delete Account")
    print("8. Logout")
    print("**********************************************")

def main():
    """Main function to run the banking application."""
    accounts = load_accounts()  # Load existing accounts from file
    logged_in_account = None

    while True:
        if not logged_in_account:
            display_initial_menu()
            choice = input("\nSelect an option 1-3: ")
            if choice == '1':
                create_account(accounts)
            elif choice == '2':
                logged_in_account = login(accounts)
            elif choice == '3':
                confirm_exit = input("Are you sure you want to exit? (yes/no): ").lower()
                if confirm_exit == "yes":
                    save_accounts(accounts)  # Save accounts before exiting
                    print("\nExiting the program. Thank you for using our banking application!")
                    break  # Exit the program
                elif confirm_exit == "no":
                    continue  # Continue running the program
                else:
                    print("Invalid input. Please enter 'yes' or 'no'.")
            else:
                print("Invalid choice. Please select options 1, 2, or 3.")
            input("\nPress Enter to return to the menu...")  # Pause before returning to the menu
        else:
            display_account_menu()
            choice = input("\nSelect an option 1-8: ")
            if choice == '1':
                view_balance(accounts, logged_in_account)
            elif choice == '2':
                deposit(accounts, logged_in_account)
            elif choice == '3':
                withdraw(accounts, logged_in_account)
            elif choice == '4':
                transfer(accounts, logged_in_account)
            elif choice == '5':
                view_transaction_history(accounts, logged_in_account)
            elif choice == '6':
                update_information(accounts, logged_in_account)
            elif choice == '7':
                delete_account(accounts, logged_in_account)
                logged_in_account = None  # Logout after deleting account
            elif choice == '8':
                logged_in_account = None  # Logout
                print("\nLogged out successfully.")
            else:
                print("Invalid choice. Please select options 1 to 8.")
            input("\nPress Enter to return to the menu...")  # Pause before returning to the menu

def create_account(accounts):
    """Create a new account with validation and initial deposit."""
    while True:
        account_number = input("Enter new account number (6 digits): ")
        if account_number.isdigit() and len(account_number) == 6:
            if account_number in accounts:
                print("Account already exists. Please choose a different account number.")
            else:
                break
        else:
            print("Invalid account number. It must be a 6-digit number.")

    while True:
        account_holder_name = input("Enter account holder's name: ")
        if account_holder_name:
            break
        else:
            print("Account holder's name cannot be empty.")

    while True:
        pin = input("Enter a 5-digit PIN: ")
        if pin.isdigit() and len(pin) == 5:
            break
        else:
            print("Invalid PIN. It must be a 5-digit number.")

    while True:
        try:
            initial_deposit = float(input("Enter initial deposit amount: "))
            if initial_deposit >= 0:
                break
            else:
                print("Initial deposit cannot be negative.")
        except ValueError:
            print("Invalid amount. Please enter a numeric value.")

    # Create the account with initial details
    accounts[account_number] = {
        "name": account_holder_name,
        "pin": pin,
        "balance": initial_deposit,
        "transactions": [f"Initial deposit: R{initial_deposit:.2f}"]
    }
    save_accounts(accounts)  # Save accounts after creating

    print(f"\nAccount no. {account_number} created for {account_holder_name} with an initial deposit of R{initial_deposit:.2f}.")
    print("Account creation successful.")

def login(accounts):
    """Login to an existing account."""
    while True:
        account_number = input("Enter account number: ")
        pin = input("Enter PIN: ")

        if account_number in accounts and accounts[account_number]["pin"] == pin:
            print(f"Login successful. Welcome, {accounts[account_number]['name']}!")
            return account_number
        else:
            print("Invalid account number or PIN. Please try again.")
            retry = input("Would you like to try again? (yes/no): ").lower()
            if retry != "yes":
                return None

def view_balance(accounts, account_number):
    """View balance of an account."""
    if account_number in accounts:
        account_details = accounts[account_number]
        account_holder_name = account_details['name']
        balance = account_details['balance']
        print("\n***************************************")
        print(f"Account Holder: {account_holder_name}")
        print(f"Account Number: {account_number}")
        print(f"Balance: R{balance:.2f}")
        print("***************************************")
    else:
        print("Account not found.")

def deposit(accounts, account_number):
    """Deposit money into an account."""
    if account_number not in accounts:
        print("Account not found.")
        return
    
    while True:
        try:
            amount = float(input("Enter the deposit amount: "))
            if amount <= 0:
                print("Deposit amount must be positive.")
            else:
                break
        except ValueError:
            print("Invalid amount. Please enter a numeric value.")

    transaction = {
        "timestamp": datetime.now().isoformat(),
        "description": f"Deposit: R{amount:.2f}",
        "amount": amount
    }

    accounts[account_number]["transactions"].append(transaction)
    accounts[account_number]["balance"] += amount

    save_accounts(accounts)  # Save accounts after depositing
    print(f"R{amount:.2f} has been deposited into account '{account_number}'.")

def withdraw(accounts, account_number):
    """Withdraw money from an account."""
    if account_number not in accounts:
        print("Account not found.")
        return
    
    while True:
        try:
            amount = float(input("Enter a withdrawal amount: "))
            if amount <= 0:
                print("Withdrawal amount must be positive.")
                continue
            if accounts[account_number]["balance"] < amount:
                print("Insufficient funds. Withdrawal canceled.")
                return
            break
        except ValueError:
            print("Invalid amount. Please enter a numeric value.")

    transaction = {
        "timestamp": datetime.now().isoformat(),
        "description": f"Withdraw: R{amount:.2f}",
        "amount": amount
    }
    accounts[account_number]["balance"] -= amount
    accounts[account_number]["transactions"].append(transaction)
    save_accounts(accounts)  # Save accounts after withdrawing
    print(f"R{amount:.2f} withdrawn from account {account_number}.")

def transfer(accounts, account_number):
    """Transfer money between accounts."""
    to_account = input("Enter recipient account number: ")

    if to_account not in accounts:
        print("Recipient account not found.")
        return
    if account_number == to_account:
        print("Cannot transfer funds to the same account.")
        return

    while True:
        try:
            amount = float(input("Enter the transfer amount: "))
            if amount <= 0:
                print("Transfer amount must be positive.")
                continue
            if accounts[account_number]["balance"] < amount:
                print("Insufficient funds. Transfer canceled.")
                return
            break
        except ValueError:
            print("Invalid amount. Please enter a numeric value.")

    # Confirm the transfer
    confirm_transfer = input(f"Confirm transfer of R{amount:.2f} to account {to_account}? (yes/no): ").lower()
    if confirm_transfer != "yes":
        print("Transfer canceled.")
        return

    # Record the transaction for both accounts
    transfer_out = {
        "timestamp": datetime.now().isoformat(),
        "description": f"Transfer to {to_account}: R{amount:.2f}",
        "amount": amount
    }
    transfer_in = {
        "timestamp": datetime.now().isoformat(),
        "description": f"Transfer from {account_number}: R{amount:.2f}",
        "amount": amount
    }
    accounts[account_number]["balance"] -= amount
    accounts[account_number]["transactions"].append(transfer_out)
    accounts[to_account]["balance"] += amount
    accounts[to_account]["transactions"].append(transfer_in)
    save_accounts(accounts)  # Save accounts after transferring
    print(f"R{amount:.2f} transferred from account {account_number} to account {to_account}.")

def view_transaction_history(accounts, account_number):
    """View the transaction history of an account."""
    if not accounts[account_number]["transactions"]:
        print("No transactions found.")
        return

    print("\n*************************************************")
    print(f"Transaction History for Account {account_number}")
    print("*************************************************")

    for transaction in accounts[account_number]["transactions"]:
        try:
            if isinstance(transaction, str):
                print(transaction)  # Print initial string transaction
            elif isinstance(transaction, dict):
                timestamp = datetime.fromisoformat(transaction.get("timestamp", ""))
                description = transaction.get("description", "")
                amount = transaction.get("amount", 0.0)
                print(f"{timestamp.strftime('%Y-%m-%d %H:%M:%S')} - {description}: R{amount:.2f}")
            else:
                print(f"Error: Unexpected transaction format {transaction}")
        except ValueError:
            print(f"Error: Invalid timestamp format for transaction {transaction}")
        except KeyError as e:
            print(f"Error: Transaction is missing '{e.args[0]}' field.")

    print("**********************************************")

def update_information(accounts, account_number):
    """Update account holder's information (name and PIN)."""
    print("\n*************************************************")
    print(f"Update Information for Account {account_number}")
    print("*************************************************")

    while True:
        print("\nWhat would you like to update?")
        print("1. Name")
        print("2. PIN")
        print("3. Cancel")
        choice = input("Enter your choice (1-3): ")

        if choice == '1':
            new_name = input("Enter new name: ")
            if new_name:
                accounts[account_number]["name"] = new_name
                save_accounts(accounts)  # Save accounts after updating
                print("Name updated successfully.")
            else:
                print("Name cannot be empty. Update canceled.")
        elif choice == '2':
            new_pin = input("Enter new 5-digit PIN: ")
            if new_pin.isdigit() and len(new_pin) == 5:
                accounts[account_number]["pin"] = new_pin
                save_accounts(accounts)  # Save accounts after updating
                print("PIN updated successfully.")
            else:
                print("Invalid PIN format. Update canceled.")
        elif choice == '3':
            print("Update canceled.")
            break
        else:
            print("Invalid choice. Please enter options 1, 2, or 3.")

def delete_account(accounts, account_number):
    """Delete an account."""
    confirmation = input(f"Are you sure you want to delete account {account_number}? (yes/no): ").lower()

    if confirmation == "yes":
        del accounts[account_number]
        save_accounts(accounts)  # Save accounts after deleting
        print(f"Account {account_number} deleted.")
    elif confirmation == "no":
        print("Deletion canceled.")
    else:
        print("Invalid input. Deletion canceled.")

if __name__ == "__main__":
    main()
