import unittest
from unittest.mock import patch
from io import StringIO
import json
import os
from datetime import datetime
from project import create_account, login, view_balance, deposit, withdraw, transfer, view_transaction_history, update_information, delete_account

# Define a temporary file name for testing
TEST_ACCOUNTS_FILE = "data/test_accounts.json"

class TestBankingFunctions(unittest.TestCase):

    def setUp(self):
        """Create a temporary test accounts file."""
        self.accounts = {}

    def tearDown(self):
        """Remove the temporary test accounts file."""
        if os.path.exists(TEST_ACCOUNTS_FILE):
            os.remove(TEST_ACCOUNTS_FILE)

    def test_create_account(self):
        """Test the create_account function."""
        account_number_input = "123456"
        account_holder_name_input = "Test Sufyaan"
        pin_input = "12345"
        initial_deposit_input = 5000.0

        # Mock user input and run the function
        with patch('builtins.input', side_effect=[account_number_input, account_holder_name_input, pin_input, initial_deposit_input]):
            create_account(self.accounts)

        # Check if account was created correctly
        self.assertIn(account_number_input, self.accounts)
        self.assertEqual(self.accounts[account_number_input]["name"], account_holder_name_input)
        self.assertEqual(self.accounts[account_number_input]["pin"], pin_input)
        self.assertEqual(self.accounts[account_number_input]["balance"], initial_deposit_input)

    def test_login(self):
        """Test the login function."""
        account_number_input = "123456"
        pin_input = "12345"
        account_holder_name = "Test Sufyaan"
        initial_balance = 5000.0
        self.accounts[account_number_input] = {
            "name": account_holder_name,
            "pin": pin_input,
            "balance": initial_balance,
            "transactions": []
        }

        # Mock user input and run the function
        with patch('builtins.input', side_effect=[account_number_input, pin_input]):
            logged_in_account = login(self.accounts)

        # Check if login was successful
        self.assertEqual(logged_in_account, account_number_input)

    def test_view_balance(self):
        """Test the view_balance function."""
        account_number = "123456"
        account_holder_name = "Test Sufyaan"
        initial_balance = 5000.0
        self.accounts[account_number] = {
            "name": account_holder_name,
            "pin": "12345",
            "balance": initial_balance,
            "transactions": []
        }

        # Redirect stdout to capture print output
        output = StringIO()
        with patch('sys.stdout', new=output):
            view_balance(self.accounts, account_number)

        # Check if the balance was correctly displayed
        expected_output = f"Balance: R{initial_balance:.2f}\n"
        self.assertIn(expected_output, output.getvalue())

    def test_deposit(self):
        """Test the deposit function."""
        account_number = "123456"
        initial_balance = 5000.0
        deposit_amount = 500.0
        self.accounts[account_number] = {
            "name": "Test Sufyaan",
            "pin": "12345",
            "balance": initial_balance,
            "transactions": []
        }

        # Mock user input and run the function
        with patch('builtins.input', return_value=deposit_amount):
            deposit(self.accounts, account_number)

        # Check if the deposit was processed correctly
        self.assertEqual(self.accounts[account_number]["balance"], initial_balance + deposit_amount)

    def test_withdraw(self):
        """Test the withdraw function."""
        account_number = "123456"
        initial_balance = 5000.0
        withdraw_amount = 300.0
        self.accounts[account_number] = {
            "name": "Test Sufyaan",
            "pin": "12345",
            "balance": initial_balance,
            "transactions": []
        }

        # Mock user input and run the function
        with patch('builtins.input', return_value=withdraw_amount):
            withdraw(self.accounts, account_number)

        # Check if the withdrawal was processed correctly
        self.assertEqual(self.accounts[account_number]["balance"], initial_balance - withdraw_amount)

    def test_transfer(self):
        """Test the transfer function."""
        account_number_1 = "123456"
        account_number_2 = "654321"
        initial_balance_1 = 100.0
        initial_balance_2 = 50.0
        transfer_amount = 50.0
        self.accounts[account_number_1] = {
            "name": "Test Sufyaan 1",
            "pin": "12345",
            "balance": initial_balance_1,
            "transactions": []
        }
        self.accounts[account_number_2] = {
            "name": "Test Sufyaan 2",
            "pin": "54321",
            "balance": initial_balance_2,
            "transactions": []
        }

        # Mock user input and run the function
        with patch('builtins.input', side_effect=[account_number_2, transfer_amount, "yes"]):
            transfer(self.accounts, account_number_1)

        # Check if the transfer was processed correctly
        self.assertEqual(self.accounts[account_number_1]["balance"], initial_balance_1 - transfer_amount)
        self.assertEqual(self.accounts[account_number_2]["balance"], initial_balance_2 + transfer_amount)

    def test_view_transaction_history(self):
        """Test the view_transaction_history function."""
        account_number = "123456"
        transaction_1 = {
            "timestamp": datetime.now().isoformat(),
            "description": "Deposit: R500.00",
            "amount": 500.0
        }
        transaction_2 = {
            "timestamp": datetime.now().isoformat(),
            "description": "Withdraw: R300.00",
            "amount": 300.0
        }
        self.accounts[account_number] = {
            "name": "Test Sufyaan",
            "pin": "12345",
            "balance": 1000.0,
            "transactions": [transaction_1, transaction_2]
        }

        # Redirect stdout to capture print output
        output = StringIO()
        with patch('sys.stdout', new=output):
            view_transaction_history(self.accounts, account_number)

        # Check if the transaction history was correctly displayed
        expected_output_1 = f"{transaction_1['description']}: R{transaction_1['amount']:.2f}\n"
        expected_output_2 = f"{transaction_2['description']}: R{transaction_2['amount']:.2f}\n"
        self.assertIn(expected_output_1, output.getvalue())
        self.assertIn(expected_output_2, output.getvalue())

if __name__ == "__main__":
    unittest.main()

